package es.florida.serviciosred;

import java.io.IOException;

import java.io.InputStream;

import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

import java.io.BufferedReader;
import com.sun.net.httpserver.*;

import com.google.gson.Gson;

public class GestorHTTP implements HttpHandler{

	//atribuots
	int temperaturaActual = 15;
	int temperaturaTermostato = 15;
	
	int temperaturaAlcanzar = 0;
	
	@Override  //metodo handler para relalizar las acciones de tipo CRUD
	public void handle(HttpExchange httpExchange) throws IOException{
		String requestParamValue=null;
		if("GET".equals(httpExchange.getRequestMethod())) {
			requestParamValue= handleGetRequest(httpExchange);
			
			handleGETResponse(httpExchange,requestParamValue);
	} else if("POST".equals(httpExchange.getRequestMethod())) {
			requestParamValue= handlePostRequest(httpExchange);
			try {
				handlePOSTResponse(httpExchange,requestParamValue);
			} catch (IOException | InterruptedException | MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	//Metodo donde recibimos en servidor el parametro introducido de peticion
	private String handleGetRequest(HttpExchange httpExchange) {
		
		System.out.println("Recibida URI tipo GET: " + httpExchange.getRequestURI().toString());
		
		return httpExchange.getRequestURI().toString().split("\\?")[1];
	}
	
	//Metodo que envvia respuesta del servidor al cliente que realiza el GET
	private void handleGETResponse( HttpExchange httpExchange, String requestParamValue) throws IOException{
		
		OutputStream outputStream = httpExchange.getResponseBody();
		
		String htmlResponse = "<html><body><h1>Temperatura actual: " + temperaturaActual + "</h1><br><h1>Temperatura termostato: " + temperaturaTermostato + "</h1></body></html>";
		httpExchange.sendResponseHeaders(200,htmlResponse.length());
		outputStream.write(htmlResponse.getBytes());
		outputStream.flush();
		outputStream.close();
		System.out.println("Devuelve respuesta HTML: " + htmlResponse);
	}
	
	//Metodo donde recibimos en servidor el parametro introducido de peticion POST y procesa las lineas
	private String handlePostRequest(HttpExchange httpExchange) {
		System.out.println("Recibida URI tipo POST: " + httpExchange.getRequestBody().toString());
		InputStream is = httpExchange.getRequestBody();
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader br = new BufferedReader(isr);
		StringBuilder sb = new StringBuilder();
		String line;
		try {
			while((line = br.readLine()) != null ) {
				sb.append(line);
			}
			br.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
		//return httpExchange.getRequestBody().toString();
		return sb.toString();
	}
	
	//Respuesta obtenida a partir de la peticion post en el cliente
	private void handlePOSTResponse(HttpExchange httpExchange, String requestParamValue) throws IOException, InterruptedException, MessagingException{
		
		//Si el parametro introducido por POST contiene setTemperatura entrara aqui.
        if(requestParamValue.contains("setTemperatura")) {
        	
        	OutputStream outputStream = httpExchange.getResponseBody();
        	
        	//Guardamos la temperatura que nos da el cliente(deseada)
    		temperaturaTermostato = Integer.parseInt(requestParamValue.toString().split("=")[1]);
    		System.out.println("Servidor recibe el nuevo parametro para temperatura: " + temperaturaTermostato);
            String htmlResponse= "Respuesta del servidor: La temperatura se ha establezido en " + temperaturaTermostato;
            
            httpExchange.sendResponseHeaders(200, htmlResponse.length());
            outputStream.write(htmlResponse.getBytes());
            outputStream.flush();
            outputStream.close();
        	 
        	regularTemperatura();
        }
        
      //Si el parametro introducido por POST contiene notificarAveria entrara aqui.
        if(requestParamValue.contains("notificarAveria")) {
        	
        	OutputStream outputStream = httpExchange.getResponseBody();
    
            String htmlResponse= "Tu aver�a ha sido notificada a la guardia de la noche! The king in the nord!";
            
            httpExchange.sendResponseHeaders(200, htmlResponse.length());
            outputStream.write(htmlResponse.getBytes());
            outputStream.flush();
            outputStream.close();
            
            String part1 = requestParamValue.toString().split(";")[0];
            
            //Conseguimos a partir del parametro del post el email y la password que nos envian
            String email = part1.split("=")[1];
            String password = requestParamValue.toString().split("pass_remitente=")[1];
           
            //pasamos al metodo de envio de emails el email y la pass
            envioMail(email,password);
        } 
	}

	//Funcion que regula la temperatura
	synchronized public void regularTemperatura() throws InterruptedException {
		
		
		//Mientras la temperatura indicada por POST sea inferior que la temperatura actual...
		System.out.println("Temperatura termostato: " + temperaturaTermostato);
		while(temperaturaActual < temperaturaTermostato ) { //subir temperatura
			//5 Segundos de espera y incremento de 1 en temperatura
			Thread.sleep(5000);
			temperaturaActual++;
			System.out.println("Temperatura actual: " + temperaturaActual);
		}
		
		//Mientras la temperatura indicada por POST sea superior que la temperatura actual...
		while(temperaturaActual > temperaturaTermostato ) { //bajar temperatura
			//5 Segundos de espera y disminucion de 1 en temperatura
			Thread.sleep(5000);
			temperaturaActual--;
			System.out.println("Temperatura actual: " + temperaturaActual);
		}
	}
	
	//Metodo que envia email al Destino eleguido por POST
	public static void envioMail(String email, String password) throws UnsupportedEncodingException, MessagingException {
			
		String strMensaje = "Mi viejo amigo cuervo necesito de tus dotes tecnicas para reparar la averia de mis estufas de pellets"
				+ ", a cambio pedire al rei que te libere de tu juramento!";
		String strAsunto = "AVERIA";
		String emailRemitente = email;
		
		
		String emailRemitentePass = password;
		String hostEmail = "smtp.gmail.com";
		String portEmail = "587";
		String[] emailDestino = {"mantenimientoinvernalia@gmail.com","megustaelfresquito@gmail.com","jacasi01@floridauniversitaria.es"};
		String[] anexo = {"pa_que_te_acuerdes_de_tu_lord.jpg", "mapa.pdf"};
		
		System.out.println("Envio de correo");
		System.out.println(" > Remitente: " + email);
		
		for (int i = 0; i < emailDestino.length; i++) {
			System.out.println(" > Destino " + (i + 1) + ": " + emailDestino[i]);
		}
		
		for(int i = 0; i < anexo.length; i++) {
			System.out.println(" > Anexo " + (i + 1) + ": " + anexo[i]);
		}
		
		//AJUSTAMOS PROPIEDADES
		Properties props = System.getProperties();
		props.put("mail.smtp.host", hostEmail);
		props.put("mail.smtp.user", emailRemitente);
		props.put("mail.smtp.clave", emailRemitentePass);
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.port", portEmail);
		
		Session session = Session.getDefaultInstance(props);
		
		MimeMessage message = new MimeMessage(session);
		message.setFrom(new InternetAddress(emailRemitente));
		
		for(int i = 0; i < emailDestino.length; i++) {
			message.addRecipients(Message.RecipientType.TO, emailDestino[i]);
		}
		message.setSubject(strAsunto);
		
		Multipart multipart = new MimeMultipart();
		
		BodyPart messageBodyPart1 = new MimeBodyPart();
		messageBodyPart1.setText(strMensaje);
		
		multipart.addBodyPart(messageBodyPart1);
		
		for(int i = 0; i < anexo.length; i++) {
			
			BodyPart messageBodyPartAnexo = new MimeBodyPart();
			DataSource src = new FileDataSource(anexo[i]);
			messageBodyPartAnexo.setDataHandler(new DataHandler(src));
			messageBodyPartAnexo.setFileName(anexo[i]);
			multipart.addBodyPart(messageBodyPartAnexo);	
		}
		
		message.setContent(multipart);
		
		Transport transport = session.getTransport("smtp");
		transport.connect(hostEmail, emailRemitente, emailRemitentePass);
		transport.sendMessage(message, message.getAllRecipients());
		transport.close();
	}
	
}

